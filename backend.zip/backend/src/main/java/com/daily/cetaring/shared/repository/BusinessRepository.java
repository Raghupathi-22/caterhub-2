package com.daily.cetaring.shared.repository;

import com.daily.cetaring.shared.entity.Business;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface BusinessRepository extends JpaRepository<Business, Long> {
    Optional<Business> findFirstByIsActiveTrueAndDeletedAtIsNullOrderByIdAsc();
}

