package com.daily.cetaring.features.worker.dto;

import com.daily.cetaring.features.worker.entity.JobAssignment;
import com.daily.cetaring.features.worker.entity.WorkerAvailability;
import com.daily.cetaring.features.worker.entity.WorkerDocument;
import com.daily.cetaring.features.worker.entity.WorkerProfile;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public final class WorkerDtos {
    private WorkerDtos() {
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class CreateWorkerProfileRequest {
        @NotNull(message = "User id is required")
        private Long userId;

        @NotNull(message = "Worker type is required")
        private WorkerProfile.WorkerType workerType;

        @NotNull(message = "Experience years is required")
        @Min(value = 0, message = "Experience years cannot be negative")
        private Integer experienceYears;

        private String skills;
        private String preferredAreas;
        private String languages;
        private String bio;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UpdateWorkerStatusRequest {
        @NotNull(message = "Status is required")
        private WorkerProfile.WorkerStatus status;

        private Long adminUserId;
        private String rejectionReason;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class UpsertAvailabilityRequest {
        @NotNull(message = "Available date is required")
        private LocalDate availableDate;

        @NotNull(message = "Start time is required")
        private LocalTime startTime;

        @NotNull(message = "End time is required")
        private LocalTime endTime;

        private WorkerAvailability.AvailabilityStatus status;
        private String notes;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class AddDocumentRequest {
        @NotNull(message = "Document type is required")
        private WorkerDocument.DocumentType documentType;

        @NotBlank(message = "File name is required")
        private String fileName;

        @NotBlank(message = "File URL is required")
        private String fileUrl;

        private String contentType;

        @Positive(message = "File size must be positive")
        private Long fileSizeBytes;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class AssignWorkerRequest {
        @NotNull(message = "Booking id is required")
        private Long bookingId;

        @NotNull(message = "Worker profile id is required")
        private Long workerProfileId;

        @NotNull(message = "Assigned by user id is required")
        private Long assignedByUserId;

        private String notes;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class RespondAssignmentRequest {
        @NotNull(message = "Status is required")
        private JobAssignment.AssignmentStatus status;

        private String declineReason;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class WorkerProfileResponse {
        private Long id;
        private Long userId;
        private String username;
        private String fullName;
        private WorkerProfile.WorkerType workerType;
        private WorkerProfile.WorkerStatus status;
        private Integer experienceYears;
        private String skills;
        private String preferredAreas;
        private String languages;
        private String bio;
        private BigDecimal rating;
        private Integer totalRatings;
        private LocalDateTime approvedAt;
        private LocalDateTime createdAt;
        private LocalDateTime updatedAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class AvailabilityResponse {
        private Long id;
        private Long workerProfileId;
        private LocalDate availableDate;
        private LocalTime startTime;
        private LocalTime endTime;
        private WorkerAvailability.AvailabilityStatus status;
        private String notes;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class DocumentResponse {
        private Long id;
        private Long workerProfileId;
        private WorkerDocument.DocumentType documentType;
        private String fileName;
        private String fileUrl;
        private String contentType;
        private Long fileSizeBytes;
        private WorkerDocument.DocumentStatus status;
        private LocalDateTime reviewedAt;
        private String rejectionReason;
        private LocalDateTime createdAt;
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Builder
    public static class AssignmentResponse {
        private Long id;
        private Long bookingId;
        private Long workerProfileId;
        private Long assignedByUserId;
        private WorkerProfile.WorkerType workerType;
        private JobAssignment.AssignmentStatus status;
        private LocalDateTime offeredAt;
        private LocalDateTime respondedAt;
        private LocalDateTime completedAt;
        private String notes;
        private String declineReason;
    }
}

