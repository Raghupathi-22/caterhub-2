package com.daily.cetaring.shared.repository;

import com.daily.cetaring.shared.entity.RefreshToken;
import com.daily.cetaring.shared.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface RefreshTokenRepository extends JpaRepository<RefreshToken, Long> {

    Optional<RefreshToken> findByToken(String token);

    List<RefreshToken> findByUser(User user);

    void deleteByUserAndRevokedTrue(User user);

    void deleteByExpiresAtBefore(LocalDateTime expiresAt);
}

