package com.daily.cetaring.features.auth.mapper;

import com.daily.cetaring.shared.dto.UserDTO;
import com.daily.cetaring.shared.entity.User;
import org.mapstruct.Mapper;

@Mapper(componentModel = "spring")
public interface UserMapper {

    UserDTO toDTO(User user);

    User toEntity(UserDTO userDTO);
}

