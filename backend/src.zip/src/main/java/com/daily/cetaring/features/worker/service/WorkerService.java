package com.daily.cetaring.features.worker.service;

import com.daily.cetaring.features.booking.entity.Booking;
import com.daily.cetaring.features.booking.repository.BookingRepository;
import com.daily.cetaring.features.worker.dto.WorkerDtos;
import com.daily.cetaring.features.worker.entity.JobAssignment;
import com.daily.cetaring.features.worker.entity.WorkerAvailability;
import com.daily.cetaring.features.worker.entity.WorkerDocument;
import com.daily.cetaring.features.worker.entity.WorkerProfile;
import com.daily.cetaring.features.worker.repository.JobAssignmentRepository;
import com.daily.cetaring.features.worker.repository.WorkerAvailabilityRepository;
import com.daily.cetaring.features.worker.repository.WorkerDocumentRepository;
import com.daily.cetaring.features.worker.repository.WorkerProfileRepository;
import com.daily.cetaring.shared.entity.User;
import com.daily.cetaring.shared.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
@Transactional
public class WorkerService {

    private final WorkerProfileRepository workerProfileRepository;
    private final WorkerAvailabilityRepository workerAvailabilityRepository;
    private final WorkerDocumentRepository workerDocumentRepository;
    private final JobAssignmentRepository jobAssignmentRepository;
    private final UserRepository userRepository;
    private final BookingRepository bookingRepository;

    public WorkerDtos.WorkerProfileResponse createProfile(WorkerDtos.CreateWorkerProfileRequest request) {
        if (workerProfileRepository.existsByUserIdAndDeletedAtIsNull(request.getUserId())) {
            throw new IllegalArgumentException("Worker profile already exists for this user");
        }

        User user = userRepository.findById(request.getUserId())
            .orElseThrow(() -> new IllegalArgumentException("User not found"));

        WorkerProfile profile = WorkerProfile.builder()
            .user(user)
            .workerType(request.getWorkerType())
            .experienceYears(request.getExperienceYears())
            .skills(trimToNull(request.getSkills()))
            .preferredAreas(trimToNull(request.getPreferredAreas()))
            .languages(trimToNull(request.getLanguages()))
            .bio(trimToNull(request.getBio()))
            .status(WorkerProfile.WorkerStatus.PENDING_VERIFICATION)
            .build();

        return mapProfile(workerProfileRepository.save(profile));
    }

    @Transactional(readOnly = true)
    public WorkerDtos.WorkerProfileResponse getProfile(Long profileId) {
        return mapProfile(getProfileEntity(profileId));
    }

    @Transactional(readOnly = true)
    public WorkerDtos.WorkerProfileResponse getProfileByUserId(Long userId) {
        return workerProfileRepository.findByUserIdAndDeletedAtIsNull(userId)
            .map(this::mapProfile)
            .orElseThrow(() -> new IllegalArgumentException("Worker profile not found"));
    }

    @Transactional(readOnly = true)
    public List<WorkerDtos.WorkerProfileResponse> findActiveWorkersByType(WorkerProfile.WorkerType workerType) {
        return workerProfileRepository
            .findByWorkerTypeAndStatusAndDeletedAtIsNull(workerType, WorkerProfile.WorkerStatus.ACTIVE)
            .stream()
            .map(this::mapProfile)
            .toList();
    }

    public WorkerDtos.WorkerProfileResponse updateProfileStatus(Long profileId, WorkerDtos.UpdateWorkerStatusRequest request) {
        WorkerProfile profile = getProfileEntity(profileId);
        profile.setStatus(request.getStatus());
        profile.setRejectionReason(null);

        if (request.getStatus() == WorkerProfile.WorkerStatus.ACTIVE) {
            User admin = null;
            if (request.getAdminUserId() != null) {
                admin = userRepository.findById(request.getAdminUserId())
                    .orElseThrow(() -> new IllegalArgumentException("Admin user not found"));
            }
            profile.setApprovedBy(admin);
            profile.setApprovedAt(LocalDateTime.now());
        } else if (request.getStatus() == WorkerProfile.WorkerStatus.REJECTED) {
            profile.setApprovedBy(null);
            profile.setApprovedAt(null);
            profile.setRejectionReason(requireText(request.getRejectionReason(), "Rejection reason is required"));
        }

        return mapProfile(workerProfileRepository.save(profile));
    }

    public WorkerDtos.AvailabilityResponse addAvailability(Long profileId, WorkerDtos.UpsertAvailabilityRequest request) {
        if (!request.getStartTime().isBefore(request.getEndTime())) {
            throw new IllegalArgumentException("Start time must be before end time");
        }

        WorkerProfile profile = getProfileEntity(profileId);
        WorkerAvailability availability = WorkerAvailability.builder()
            .workerProfile(profile)
            .availableDate(request.getAvailableDate())
            .startTime(request.getStartTime())
            .endTime(request.getEndTime())
            .status(request.getStatus() == null ? WorkerAvailability.AvailabilityStatus.AVAILABLE : request.getStatus())
            .notes(trimToNull(request.getNotes()))
            .build();

        return mapAvailability(workerAvailabilityRepository.save(availability));
    }

    @Transactional(readOnly = true)
    public List<WorkerDtos.AvailabilityResponse> getAvailability(Long profileId, LocalDate startDate, LocalDate endDate) {
        getProfileEntity(profileId);
        List<WorkerAvailability> records;
        if (startDate != null && endDate != null) {
            if (startDate.isAfter(endDate)) {
                throw new IllegalArgumentException("Start date cannot be after end date");
            }
            records = workerAvailabilityRepository
                .findByWorkerProfileIdAndAvailableDateBetweenOrderByAvailableDateAscStartTimeAsc(profileId, startDate, endDate);
        } else {
            records = workerAvailabilityRepository.findByWorkerProfileIdOrderByAvailableDateAscStartTimeAsc(profileId);
        }
        return records.stream().map(this::mapAvailability).toList();
    }

    public WorkerDtos.DocumentResponse addDocument(Long profileId, WorkerDtos.AddDocumentRequest request) {
        WorkerProfile profile = getProfileEntity(profileId);
        WorkerDocument document = WorkerDocument.builder()
            .workerProfile(profile)
            .documentType(request.getDocumentType())
            .fileName(requireText(request.getFileName(), "File name is required"))
            .fileUrl(requireText(request.getFileUrl(), "File URL is required"))
            .contentType(trimToNull(request.getContentType()))
            .fileSizeBytes(request.getFileSizeBytes())
            .status(WorkerDocument.DocumentStatus.PENDING)
            .build();

        return mapDocument(workerDocumentRepository.save(document));
    }

    @Transactional(readOnly = true)
    public List<WorkerDtos.DocumentResponse> getDocuments(Long profileId) {
        getProfileEntity(profileId);
        return workerDocumentRepository.findByWorkerProfileIdOrderByCreatedAtDesc(profileId)
            .stream()
            .map(this::mapDocument)
            .toList();
    }

    public WorkerDtos.AssignmentResponse assignWorker(WorkerDtos.AssignWorkerRequest request) {
        if (jobAssignmentRepository.existsByBookingIdAndWorkerProfileId(request.getBookingId(), request.getWorkerProfileId())) {
            throw new IllegalArgumentException("Worker is already assigned to this booking");
        }

        Booking booking = bookingRepository.findById(request.getBookingId())
            .orElseThrow(() -> new IllegalArgumentException("Booking not found"));
        WorkerProfile workerProfile = getProfileEntity(request.getWorkerProfileId());
        if (workerProfile.getStatus() != WorkerProfile.WorkerStatus.ACTIVE) {
            throw new IllegalArgumentException("Only active workers can be assigned");
        }
        User assignedBy = userRepository.findById(request.getAssignedByUserId())
            .orElseThrow(() -> new IllegalArgumentException("Assigning user not found"));

        JobAssignment assignment = JobAssignment.builder()
            .booking(booking)
            .workerProfile(workerProfile)
            .assignedBy(assignedBy)
            .workerType(workerProfile.getWorkerType())
            .status(JobAssignment.AssignmentStatus.OFFERED)
            .notes(trimToNull(request.getNotes()))
            .build();

        return mapAssignment(jobAssignmentRepository.save(assignment));
    }

    public WorkerDtos.AssignmentResponse respondToAssignment(Long assignmentId, WorkerDtos.RespondAssignmentRequest request) {
        JobAssignment assignment = jobAssignmentRepository.findById(assignmentId)
            .orElseThrow(() -> new IllegalArgumentException("Assignment not found"));

        if (request.getStatus() != JobAssignment.AssignmentStatus.ACCEPTED
            && request.getStatus() != JobAssignment.AssignmentStatus.DECLINED) {
            throw new IllegalArgumentException("Workers can only accept or decline assignments");
        }
        if (assignment.getStatus() != JobAssignment.AssignmentStatus.OFFERED) {
            throw new IllegalArgumentException("Only offered assignments can be updated by workers");
        }

        assignment.setStatus(request.getStatus());
        assignment.setRespondedAt(LocalDateTime.now());
        if (request.getStatus() == JobAssignment.AssignmentStatus.DECLINED) {
            assignment.setDeclineReason(requireText(request.getDeclineReason(), "Decline reason is required"));
        } else {
            assignment.setDeclineReason(null);
        }

        return mapAssignment(jobAssignmentRepository.save(assignment));
    }

    @Transactional(readOnly = true)
    public List<WorkerDtos.AssignmentResponse> getAssignmentsForWorker(Long profileId) {
        getProfileEntity(profileId);
        return jobAssignmentRepository.findByWorkerProfileIdOrderByCreatedAtDesc(profileId)
            .stream()
            .map(this::mapAssignment)
            .toList();
    }

    @Transactional(readOnly = true)
    public List<WorkerDtos.AssignmentResponse> getAssignmentsForBooking(Long bookingId) {
        if (!bookingRepository.existsById(bookingId)) {
            throw new IllegalArgumentException("Booking not found");
        }
        return jobAssignmentRepository.findByBookingIdOrderByCreatedAtDesc(bookingId)
            .stream()
            .map(this::mapAssignment)
            .toList();
    }

    private WorkerProfile getProfileEntity(Long profileId) {
        return workerProfileRepository.findById(profileId)
            .filter(profile -> profile.getDeletedAt() == null)
            .orElseThrow(() -> new IllegalArgumentException("Worker profile not found"));
    }

    private WorkerDtos.WorkerProfileResponse mapProfile(WorkerProfile profile) {
        User user = profile.getUser();
        String fullName = String.join(" ",
            user.getFirstName() == null ? "" : user.getFirstName(),
            user.getLastName() == null ? "" : user.getLastName()
        ).trim();

        return WorkerDtos.WorkerProfileResponse.builder()
            .id(profile.getId())
            .userId(user.getId())
            .username(user.getUsername())
            .fullName(fullName.isBlank() ? user.getUsername() : fullName)
            .workerType(profile.getWorkerType())
            .status(profile.getStatus())
            .experienceYears(profile.getExperienceYears())
            .skills(profile.getSkills())
            .preferredAreas(profile.getPreferredAreas())
            .languages(profile.getLanguages())
            .bio(profile.getBio())
            .rating(profile.getRating())
            .totalRatings(profile.getTotalRatings())
            .approvedAt(profile.getApprovedAt())
            .createdAt(profile.getCreatedAt())
            .updatedAt(profile.getUpdatedAt())
            .build();
    }

    private WorkerDtos.AvailabilityResponse mapAvailability(WorkerAvailability availability) {
        return WorkerDtos.AvailabilityResponse.builder()
            .id(availability.getId())
            .workerProfileId(availability.getWorkerProfile().getId())
            .availableDate(availability.getAvailableDate())
            .startTime(availability.getStartTime())
            .endTime(availability.getEndTime())
            .status(availability.getStatus())
            .notes(availability.getNotes())
            .build();
    }

    private WorkerDtos.DocumentResponse mapDocument(WorkerDocument document) {
        return WorkerDtos.DocumentResponse.builder()
            .id(document.getId())
            .workerProfileId(document.getWorkerProfile().getId())
            .documentType(document.getDocumentType())
            .fileName(document.getFileName())
            .fileUrl(document.getFileUrl())
            .contentType(document.getContentType())
            .fileSizeBytes(document.getFileSizeBytes())
            .status(document.getStatus())
            .reviewedAt(document.getReviewedAt())
            .rejectionReason(document.getRejectionReason())
            .createdAt(document.getCreatedAt())
            .build();
    }

    private WorkerDtos.AssignmentResponse mapAssignment(JobAssignment assignment) {
        return WorkerDtos.AssignmentResponse.builder()
            .id(assignment.getId())
            .bookingId(assignment.getBooking().getId())
            .workerProfileId(assignment.getWorkerProfile().getId())
            .assignedByUserId(assignment.getAssignedBy().getId())
            .workerType(assignment.getWorkerType())
            .status(assignment.getStatus())
            .offeredAt(assignment.getOfferedAt())
            .respondedAt(assignment.getRespondedAt())
            .completedAt(assignment.getCompletedAt())
            .notes(assignment.getNotes())
            .declineReason(assignment.getDeclineReason())
            .build();
    }

    private String requireText(String value, String message) {
        String trimmed = trimToNull(value);
        if (trimmed == null) {
            throw new IllegalArgumentException(message);
        }
        return trimmed;
    }

    private String trimToNull(String value) {
        if (value == null) {
            return null;
        }
        String trimmed = value.trim();
        return trimmed.isEmpty() ? null : trimmed;
    }
}

