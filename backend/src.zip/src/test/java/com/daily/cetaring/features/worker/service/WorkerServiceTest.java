package com.daily.cetaring.features.worker.service;

import com.daily.cetaring.features.booking.entity.Booking;
import com.daily.cetaring.features.booking.repository.BookingRepository;
import com.daily.cetaring.features.worker.dto.WorkerDtos;
import com.daily.cetaring.features.worker.entity.JobAssignment;
import com.daily.cetaring.features.worker.entity.WorkerAvailability;
import com.daily.cetaring.features.worker.entity.WorkerProfile;
import com.daily.cetaring.features.worker.repository.JobAssignmentRepository;
import com.daily.cetaring.features.worker.repository.WorkerAvailabilityRepository;
import com.daily.cetaring.features.worker.repository.WorkerDocumentRepository;
import com.daily.cetaring.features.worker.repository.WorkerProfileRepository;
import com.daily.cetaring.shared.entity.User;
import com.daily.cetaring.shared.repository.UserRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.time.LocalDate;
import java.time.LocalTime;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertThrows;
import static org.junit.jupiter.api.Assertions.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

class WorkerServiceTest {

    private WorkerService workerService;

    @Mock
    private WorkerProfileRepository workerProfileRepository;
    @Mock
    private WorkerAvailabilityRepository workerAvailabilityRepository;
    @Mock
    private WorkerDocumentRepository workerDocumentRepository;
    @Mock
    private JobAssignmentRepository jobAssignmentRepository;
    @Mock
    private UserRepository userRepository;
    @Mock
    private BookingRepository bookingRepository;

    @BeforeEach
    void setUp() {
        MockitoAnnotations.openMocks(this);
        workerService = new WorkerService(
            workerProfileRepository,
            workerAvailabilityRepository,
            workerDocumentRepository,
            jobAssignmentRepository,
            userRepository,
            bookingRepository
        );
    }

    @Test
    void createProfileRejectsDuplicateUserProfile() {
        WorkerDtos.CreateWorkerProfileRequest request = WorkerDtos.CreateWorkerProfileRequest.builder()
            .userId(10L)
            .workerType(WorkerProfile.WorkerType.CHEF)
            .experienceYears(4)
            .build();
        when(workerProfileRepository.existsByUserIdAndDeletedAtIsNull(10L)).thenReturn(true);

        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> workerService.createProfile(request)
        );

        assertEquals("Worker profile already exists for this user", exception.getMessage());
        verify(workerProfileRepository, never()).save(any());
    }

    @Test
    void createProfilePersistsPendingVerificationProfile() {
        User user = user(10L);
        WorkerDtos.CreateWorkerProfileRequest request = WorkerDtos.CreateWorkerProfileRequest.builder()
            .userId(10L)
            .workerType(WorkerProfile.WorkerType.SUPERVISOR)
            .experienceYears(6)
            .skills("Team handling")
            .build();

        when(workerProfileRepository.existsByUserIdAndDeletedAtIsNull(10L)).thenReturn(false);
        when(userRepository.findById(10L)).thenReturn(Optional.of(user));
        when(workerProfileRepository.save(any(WorkerProfile.class))).thenAnswer(invocation -> {
            WorkerProfile profile = invocation.getArgument(0);
            profile.setId(99L);
            profile.setUser(user);
            profile.setStatus(WorkerProfile.WorkerStatus.PENDING_VERIFICATION);
            profile.setExperienceYears(6);
            profile.setWorkerType(WorkerProfile.WorkerType.SUPERVISOR);
            return profile;
        });

        WorkerDtos.WorkerProfileResponse response = workerService.createProfile(request);

        assertEquals(99L, response.getId());
        assertEquals(10L, response.getUserId());
        assertEquals(WorkerProfile.WorkerStatus.PENDING_VERIFICATION, response.getStatus());
        assertEquals(WorkerProfile.WorkerType.SUPERVISOR, response.getWorkerType());
    }

    @Test
    void addAvailabilityRejectsInvalidTimeWindow() {
        WorkerDtos.UpsertAvailabilityRequest request = WorkerDtos.UpsertAvailabilityRequest.builder()
            .availableDate(LocalDate.now().plusDays(1))
            .startTime(LocalTime.of(18, 0))
            .endTime(LocalTime.of(9, 0))
            .build();

        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> workerService.addAvailability(1L, request)
        );

        assertEquals("Start time must be before end time", exception.getMessage());
    }

    @Test
    void assignWorkerRequiresActiveWorker() {
        WorkerProfile profile = workerProfile(20L, WorkerProfile.WorkerStatus.PENDING_VERIFICATION);
        WorkerDtos.AssignWorkerRequest request = WorkerDtos.AssignWorkerRequest.builder()
            .bookingId(30L)
            .workerProfileId(20L)
            .assignedByUserId(1L)
            .build();

        when(jobAssignmentRepository.existsByBookingIdAndWorkerProfileId(30L, 20L)).thenReturn(false);
        when(bookingRepository.findById(30L)).thenReturn(Optional.of(Booking.builder().id(30L).build()));
        when(workerProfileRepository.findById(20L)).thenReturn(Optional.of(profile));

        IllegalArgumentException exception = assertThrows(
            IllegalArgumentException.class,
            () -> workerService.assignWorker(request)
        );

        assertEquals("Only active workers can be assigned", exception.getMessage());
        verify(jobAssignmentRepository, never()).save(any());
    }

    @Test
    void respondToAssignmentAcceptsOnlyOfferedAssignments() {
        JobAssignment assignment = JobAssignment.builder()
            .id(40L)
            .status(JobAssignment.AssignmentStatus.OFFERED)
            .booking(Booking.builder().id(30L).build())
            .workerProfile(workerProfile(20L, WorkerProfile.WorkerStatus.ACTIVE))
            .assignedBy(user(1L))
            .workerType(WorkerProfile.WorkerType.CHEF)
            .build();

        when(jobAssignmentRepository.findById(40L)).thenReturn(Optional.of(assignment));
        when(jobAssignmentRepository.save(any(JobAssignment.class))).thenAnswer(invocation -> invocation.getArgument(0));

        WorkerDtos.AssignmentResponse response = workerService.respondToAssignment(
            40L,
            WorkerDtos.RespondAssignmentRequest.builder()
                .status(JobAssignment.AssignmentStatus.ACCEPTED)
                .build()
        );

        assertEquals(JobAssignment.AssignmentStatus.ACCEPTED, response.getStatus());
        assertTrue(response.getRespondedAt() != null);
    }

    private User user(Long id) {
        return User.builder()
            .id(id)
            .username("user" + id)
            .email("user" + id + "@example.com")
            .phoneNumber("90000000" + id)
            .passwordHash("hash")
            .firstName("User")
            .lastName(String.valueOf(id))
            .build();
    }

    private WorkerProfile workerProfile(Long id, WorkerProfile.WorkerStatus status) {
        return WorkerProfile.builder()
            .id(id)
            .user(user(100L + id))
            .workerType(WorkerProfile.WorkerType.CHEF)
            .status(status)
            .experienceYears(5)
            .build();
    }
}

